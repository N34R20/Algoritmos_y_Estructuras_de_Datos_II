package aed;

public class Horario {

    public Horario(int hora, int minutos) {
        throw new UnsupportedOperationException("No implementada aun");
    }

    public int hora() {
        throw new UnsupportedOperationException("No implementada aun");
    }

    public int minutos() {
        throw new UnsupportedOperationException("No implementada aun");
    }

    @Override
    public String toString() {
        throw new UnsupportedOperationException("No implementada aun");
    }

    @Override
    public boolean equals(Object otro) {
        throw new UnsupportedOperationException("No implementada aun");
    }

}
