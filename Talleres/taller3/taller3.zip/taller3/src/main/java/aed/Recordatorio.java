package aed;

public class Recordatorio {

    public Recordatorio(String mensaje, Fecha fecha, Horario horario) {
        throw new UnsupportedOperationException("No implementada aun");
    }

    public Horario horario() {
        throw new UnsupportedOperationException("No implementada aun");
    }

    public Fecha fecha() {
        throw new UnsupportedOperationException("No implementada aun");
    }

    public String mensaje() {
        throw new UnsupportedOperationException("No implementada aun");
    }

    @Override
    public String toString() {
        throw new UnsupportedOperationException("No implementada aun");
    }

    @Override
    public boolean equals(Object otro) {
        throw new UnsupportedOperationException("No implementada aun");
    }

}
