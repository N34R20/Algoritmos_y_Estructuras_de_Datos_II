package aed;

class Funciones {
    int cuadrado(int x) {
        // COMPLETAR
        return 0;
    }

    double distancia(double x, double y) {
        // COMPLETAR
        return 0.0;
    }

    boolean esPar(int n) {
        // COMPLETAR
        return false;
    }

    boolean esBisiesto(int n) {
        // COMPLETAR
        return false;
    }

    int factorialIterativo(int n) {
        // COMPLETAR
        return 0;
    }

    int factorialRecursivo(int n) {
        // COMPLETAR
        return 0;
    }

    boolean esPrimo(int n) {
        // COMPLETAR
        return false;
    }

    int sumatoria(int[] numeros) {
        // COMPLETAR
        return 0;
    }

    int busqueda(int[] numeros, int buscado) {
        // COMPLETAR
        return 0;
    }

    boolean tienePrimo(int[] numeros) {
        // COMPLETAR
        return false;
    }

    boolean todosPares(int[] numeros) {
        // COMPLETAR
        return false;
    }

    boolean esPrefijo(String s1, String s2) {
        // COMPLETAR
        return false;
    }

    boolean esSufijo(String s1, String s2) {
        // COMPLETAR
        return false;
    }
}
