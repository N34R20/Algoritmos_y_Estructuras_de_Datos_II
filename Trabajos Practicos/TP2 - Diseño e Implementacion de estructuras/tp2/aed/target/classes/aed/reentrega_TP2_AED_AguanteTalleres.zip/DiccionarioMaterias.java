package aed;

// Invariante de Representacion de TrieMaterias:
// cumple el invariante de Trie

public class DiccionarioMaterias extends Trie<Materia> {

    // Constructor
    public DiccionarioMaterias() {

    }
}
